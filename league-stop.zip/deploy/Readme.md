# League Stop

The best application for league of legends. You won't have 0/10 in any other game with this app.
Your life will rapidly change! Trust me.

League stop is powered with slogan: "You can't lose the game, if you won't play the game!"

## Usage

Just download the league-stop.exe app and run it.
Don't worry about anything, it's fully automatic.

Now you can enjoy your life!
You're welcome!